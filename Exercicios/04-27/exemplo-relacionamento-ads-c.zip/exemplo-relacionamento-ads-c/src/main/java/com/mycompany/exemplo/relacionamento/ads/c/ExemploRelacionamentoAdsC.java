package com.mycompany.exemplo.relacionamento.ads.c;

/**
 *
 * @author luifiller
 */
public class ExemploRelacionamentoAdsC {

    public static void main(String[] args) {
        System.out.println("
    }
}
