package com.mycompany.lista.poo.encapsulamento;

/**
 *
 * @author luifiller
 */
public class Colaborador {
    private String nomeColaborador;
    private String cargoColaborador;
    private Double salarioColaborador;

    public String getNomeColaborador() {
        return nomeColaborador;
    }

    public void setNomeColaborador(String nomeColaborador) {
        this.nomeColaborador = nomeColaborador;
    }

    public String getCargoColaborador() {
        return cargoColaborador;
    }

    public void setCargoColaborador(String cargoColaborador) {
        this.cargoColaborador = cargoColaborador;
    }

    public Double getSalarioColaborador() {
        return salarioColaborador;
    }

    public void setSalarioColaborador(Double salarioColaborador) {
        this.salarioColaborador = salarioColaborador;
    }
    
    
    
}
