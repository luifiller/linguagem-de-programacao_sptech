package com.mycompany.atividade02.ac01;

/**
 *
 * @author luizn
 */
public class CalculoAluno {
    Double calcularMedia(Double nota01, Double nota02){
        return ((nota01 * 0.4) + (nota02 * 0.6));
    }
}
